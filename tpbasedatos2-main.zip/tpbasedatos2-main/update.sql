update hora h
set hor_horas_dia = 50 
where hor_fecha = '2022-08-07'